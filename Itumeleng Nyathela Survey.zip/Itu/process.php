<?php 
    if(isset($_POST["Submit"]))
        {
            $name = $_POST["name"];
            $email = $_POST["email"];
            $date = $_POST["age"];
            $contact = $_POST["contact"];
            $pizza = $_POST["food"];
            $movie = $_POST["movie"];
            $radio = $_POST["radio"];
            $out = $_POST["out"];
            $tv = $_POST["tv"];

            if(!empty($name) && !empty($email) && !empty($date) && !empty($contact) && !empty($food) && !empty($movie) && !empty($radio) && !empty($eatout) && !empty($tv))
            {
               $link = mysqli_connect("localhost", "root", "", "survey");
               if ($link==false)
                {
                    die(mysqli_connect_error());
                }
                $sql = "INSERT INTO user (first_name, email, birth, contact) VALUES('$name', '$email', '$date', '$contact')";
                $sql = "INSERT INTO food (pizza, pasta, pap, other) VALUES('$food')";
                $sql = "INSERT INTO rate (movies, radio, eatout, tv) VALUES('$movie', '$radio', '$out', '$tv')";

                if (mysqli_query($link, $sql)){
                        echo "Record inserted successfull";
                    }
                else{echo "Something went wrong ";}
            }else
                {
                    echo "Please provide all information";
                }
        }
?>